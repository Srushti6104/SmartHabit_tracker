package com.smarthabittracker.smarthabittracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmarthabittrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
