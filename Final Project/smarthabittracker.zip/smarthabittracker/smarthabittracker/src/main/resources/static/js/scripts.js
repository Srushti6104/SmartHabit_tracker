/**
 * Smart Habit Tracker JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize any interactive elements
    initializeTooltips();
    initializeFormValidation();
    initializeHabitToggle();
    
    // Add event listeners for dynamic content
    setupEventListeners();
});

/**
 * Initialize tooltip functionality
 */
function initializeTooltips() {
    // Simple tooltip implementation
    const tooltips = document.querySelectorAll('[data-tooltip]');
    
    tooltips.forEach(tooltip => {
        tooltip.addEventListener('mouseenter', function() {
            const tooltipText = this.getAttribute('data-tooltip');
            const tooltipElement = document.createElement('div');
            tooltipElement.className = 'tooltip';
            tooltipElement.textContent = tooltipText;
            
            document.body.appendChild(tooltipElement);
            
            const rect = this.getBoundingClientRect();
            tooltipElement.style.top = rect.bottom + 10 + 'px';
            tooltipElement.style.left = rect.left + (rect.width / 2) - (tooltipElement.offsetWidth / 2) + 'px';
            tooltipElement.style.opacity = '1';
        });
        
        tooltip.addEventListener('mouseleave', function() {
            const tooltipElement = document.querySelector('.tooltip');
            if (tooltipElement) {
                tooltipElement.remove();
            }
        });
    });
}

/**
 * Initialize form validation
 */
function initializeFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    highlightInvalidField(field);
                } else {
                    removeInvalidHighlight(field);
                }
            });
            
            if (!isValid) {
                event.preventDefault();
                showValidationMessage(form);
            }
        });
    });
}

/**
 * Highlight invalid form fields
 */
function highlightInvalidField(field) {
    field.classList.add('invalid');
    field.addEventListener('input', function() {
        if (field.value.trim()) {
            removeInvalidHighlight(field);
        }
    });
}

/**
 * Remove invalid highlight from form fields
 */
function removeInvalidHighlight(field) {
    field.classList.remove('invalid');
}

/**
 * Show validation message
 */
function showValidationMessage(form) {
    let validationMessage = form.querySelector('.validation-message');
    
    if (!validationMessage) {
        validationMessage = document.createElement('div');
        validationMessage.className = 'validation-message error';
        validationMessage.textContent = 'Please fill in all required fields.';
        form.insertBefore(validationMessage, form.firstChild);
    }
    
    // Auto-hide message after 5 seconds
    setTimeout(() => {
        if (validationMessage) {
            validationMessage.remove();
        }
    }, 5000);
}

/**
 * Initialize habit toggle functionality
 */
function initializeHabitToggle() {
    const habitToggles = document.querySelectorAll('.habit-toggle');
    
    habitToggles.forEach(toggle => {
        toggle.addEventListener('change', function() {
            const habitId = this.getAttribute('data-habit-id');
            const isCompleted = this.checked;
            
            // Submit form programmatically
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = `/habits/${habitId}/log`;
            
            const completedInput = document.createElement('input');
            completedInput.type = 'hidden';
            completedInput.name = 'completed';
            completedInput.value = isCompleted;
            
            form.appendChild(completedInput);
            document.body.appendChild(form);
            form.submit();
        });
    });
}

/**
 * Setup event listeners for dynamic content
 */
function setupEventListeners() {
    // Handle delete confirmations
    const deleteButtons = document.querySelectorAll('.btn-delete, button[type="submit"].btn-danger');
    
    deleteButtons.forEach(button => {
        if (!button.hasAttribute('data-confirmed')) {
            button.addEventListener('click', function(event) {
                if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                    event.preventDefault();
                }
            });
            button.setAttribute('data-confirmed', 'true');
        }
    });
    
    // Handle habit status changes
    const statusChangeButtons = document.querySelectorAll('.btn-complete, .btn-abandon');
    
    statusChangeButtons.forEach(button => {
        if (!button.hasAttribute('data-confirmed')) {
            button.addEventListener('click', function(event) {
                const action = button.classList.contains('btn-complete') ? 'complete' : 'abandon';
                const message = action === 'complete' 
                    ? 'Are you sure you want to mark this habit as completed?' 
                    : 'Are you sure you want to abandon this habit?';
                
                if (!confirm(message)) {
                    event.preventDefault();
                }
            });
            button.setAttribute('data-confirmed', 'true');
        }
    });
    
    // Handle date picker for habit logs
    const datePickers = document.querySelectorAll('input[type="date"]');
    
    datePickers.forEach(datePicker => {
        // Set default value to today if not already set
        if (!datePicker.value) {
            const today = new Date();
            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const day = String(today.getDate()).padStart(2, '0');
            datePicker.value = `${year}-${month}-${day}`;
        }
    });
}

/**
 * Format date for display
 */
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

/**
 * Calculate streak for a habit
 */
function calculateStreak(logs) {
    if (!logs || logs.length === 0) return 0;
    
    // Sort logs by date (newest first)
    logs.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    let currentDate = new Date(logs[0].date);
    currentDate.setHours(0, 0, 0, 0);
    
    // If the most recent log is not from today or yesterday, and it's not completed, return 0
    if ((today - currentDate) / (1000 * 60 * 60 * 24) > 1 && !logs[0].completed) {
        return 0;
    }
    
    // Count consecutive completed logs
    for (const log of logs) {
        const logDate = new Date(log.date);
        logDate.setHours(0, 0, 0, 0);
        
        if (log.completed) {
            streak++;
        } else {
            break;
        }
        
        // Check if the next log should be consecutive
        if (logs.indexOf(log) < logs.length - 1) {
            const nextLog = logs[logs.indexOf(log) + 1];
            const nextLogDate = new Date(nextLog.date);
            nextLogDate.setHours(0, 0, 0, 0);
            
            // If there's a gap in dates, break the streak
            if ((logDate - nextLogDate) / (1000 * 60 * 60 * 24) !== 1) {
                break;
            }
        }
    }
    
    return streak;
}

/**
 * Show success message
 */
function showSuccessMessage(message) {
    const alertContainer = document.createElement('div');
    alertContainer.className = 'alert alert-success';
    alertContainer.textContent = message;
    
    // Insert at the top of the main content
    const mainContent = document.querySelector('.main-content');
    mainContent.insertBefore(alertContainer, mainContent.firstChild);
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        alertContainer.remove();
    }, 5000);
}

/**
 * Show error message
 */
function showErrorMessage(message) {
    const alertContainer = document.createElement('div');
    alertContainer.className = 'alert alert-error';
    alertContainer.textContent = message;
    
    // Insert at the top of the main content
    const mainContent = document.querySelector('.main-content');
    mainContent.insertBefore(alertContainer, mainContent.firstChild);
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        alertContainer.remove();
    }, 5000);
}
