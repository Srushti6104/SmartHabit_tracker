package com.smarthabittracker.smarthabittracker.repository;

import com.smarthabittracker.smarthabittracker.model.Habit;
import com.smarthabittracker.smarthabittracker.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface HabitRepository extends JpaRepository<Habit, Long> {
    List<Habit> findByUser(User user);
    List<Habit> findByUserAndStatus(User user, Habit.Status status);
    
    @Query("SELECT h FROM Habit h WHERE h.user = ?1 AND h.status = ?2 ORDER BY h.startDate DESC")
    List<Habit> findByUserAndStatusOrderByStartDateDesc(User user, Habit.Status status);
    
    @Query("SELECT h FROM Habit h WHERE h.user.id = ?1 AND h.startDate <= ?2 AND h.status = 'ACTIVE'")
    List<Habit> findActiveHabitsByUserIdAndDate(Long userId, LocalDate date);
}
