package com.smarthabittracker.smarthabittracker.controller;

import com.smarthabittracker.smarthabittracker.model.Habit;
import com.smarthabittracker.smarthabittracker.model.HabitLog;
import com.smarthabittracker.smarthabittracker.model.User;
import com.smarthabittracker.smarthabittracker.service.HabitLogService;
import com.smarthabittracker.smarthabittracker.service.HabitService;
import com.smarthabittracker.smarthabittracker.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
public class DashboardController {

    private final HabitService habitService;
    private final HabitLogService habitLogService;
    private final UserService userService;

    @Autowired
    public DashboardController(HabitService habitService, HabitLogService habitLogService, UserService userService) {
        this.habitService = habitService;
        this.habitLogService = habitLogService;
        this.userService = userService;
    }

    @GetMapping("/")
    public String home() {
        // If user is authenticated, redirect to dashboard
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !auth.getName().equals("anonymousUser")) {
            return "redirect:/dashboard";
        }
        return "home";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        User currentUser = getCurrentUser();
        
        // Get active habits
        List<Habit> activeHabits = habitService.getActiveHabitsByUser(currentUser);
        
        // Get today's date
        LocalDate today = LocalDate.now();
        
        // Create a map to store habit completion status for today
        Map<Long, Boolean> todayCompletionStatus = new HashMap<>();
        
        // For each habit, check if it has been completed today
        for (Habit habit : activeHabits) {
            boolean completedToday = habitLogService.getLogByHabitAndDate(habit, today)
                    .map(HabitLog::isCompleted)
                    .orElse(false);
            todayCompletionStatus.put(habit.getId(), completedToday);
        }
        
        // Calculate streak and completion rate for each habit
        Map<Long, Integer> streaks = new HashMap<>();
        Map<Long, Double> completionRates = new HashMap<>();
        
        for (Habit habit : activeHabits) {
            // Calculate streak (simplified version)
            int streak = 0;
            LocalDate checkDate = today;
            
            while (true) {
                Optional<HabitLog> log = habitLogService.getLogByHabitAndDate(habit, checkDate);
                if (log.isPresent() && log.get().isCompleted()) {
                    streak++;
                    checkDate = checkDate.minusDays(1);
                } else {
                    break;
                }
            }
            
            streaks.put(habit.getId(), streak);
            
            // Calculate completion rate
            long totalLogs = habitLogService.getLogsByHabit(habit).size();
            long completedLogs = habitLogService.countCompletedLogsByHabitId(habit.getId());
            
            double completionRate = totalLogs > 0 ? (double) completedLogs / totalLogs * 100 : 0;
            completionRates.put(habit.getId(), completionRate);
        }
        
        model.addAttribute("user", currentUser);
        model.addAttribute("activeHabits", activeHabits);
        model.addAttribute("todayCompletionStatus", todayCompletionStatus);
        model.addAttribute("streaks", streaks);
        model.addAttribute("completionRates", completionRates);
        model.addAttribute("today", today);
        
        return "dashboard";
    }

    private User getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return userService.getUserByUsername(auth.getName())
                .orElseThrow(() -> new RuntimeException("Current user not found"));
    }
}
