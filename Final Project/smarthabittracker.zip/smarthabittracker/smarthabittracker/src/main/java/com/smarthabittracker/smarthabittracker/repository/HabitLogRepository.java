package com.smarthabittracker.smarthabittracker.repository;

import com.smarthabittracker.smarthabittracker.model.Habit;
import com.smarthabittracker.smarthabittracker.model.HabitLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface HabitLogRepository extends JpaRepository<HabitLog, Long> {
    List<HabitLog> findByHabit(Habit habit);
    List<HabitLog> findByHabitOrderByDateDesc(Habit habit);
    Optional<HabitLog> findByHabitAndDate(Habit habit, LocalDate date);
    
    @Query("SELECT COUNT(hl) FROM HabitLog hl WHERE hl.habit.id = ?1 AND hl.completed = true")
    long countCompletedLogsByHabitId(Long habitId);
    
    @Query("SELECT hl FROM HabitLog hl WHERE hl.habit.id = ?1 AND hl.date BETWEEN ?2 AND ?3 ORDER BY hl.date ASC")
    List<HabitLog> findByHabitIdAndDateBetween(Long habitId, LocalDate startDate, LocalDate endDate);
}
