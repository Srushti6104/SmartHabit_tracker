package com.smarthabittracker.smarthabittracker.service;

import com.smarthabittracker.smarthabittracker.model.Habit;
import com.smarthabittracker.smarthabittracker.model.HabitLog;
import com.smarthabittracker.smarthabittracker.repository.HabitLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class HabitLogService {

    private final HabitLogRepository habitLogRepository;

    @Autowired
    public HabitLogService(HabitLogRepository habitLogRepository) {
        this.habitLogRepository = habitLogRepository;
    }

    public List<HabitLog> getLogsByHabit(Habit habit) {
        return habitLogRepository.findByHabit(habit);
    }

    public List<HabitLog> getLogsByHabitOrderByDateDesc(Habit habit) {
        return habitLogRepository.findByHabitOrderByDateDesc(habit);
    }

    public Optional<HabitLog> getLogById(Long id) {
        return habitLogRepository.findById(id);
    }

    public Optional<HabitLog> getLogByHabitAndDate(Habit habit, LocalDate date) {
        return habitLogRepository.findByHabitAndDate(habit, date);
    }

    public List<HabitLog> getLogsByHabitIdAndDateRange(Long habitId, LocalDate startDate, LocalDate endDate) {
        return habitLogRepository.findByHabitIdAndDateBetween(habitId, startDate, endDate);
    }

    @Transactional
    public HabitLog createLog(HabitLog habitLog) {
        return habitLogRepository.save(habitLog);
    }

    @Transactional
    public HabitLog updateLog(HabitLog habitLog) {
        return habitLogRepository.save(habitLog);
    }

    @Transactional
    public void deleteLog(Long id) {
        habitLogRepository.deleteById(id);
    }

    @Transactional
    public HabitLog toggleCompletion(Long id) {
        HabitLog log = habitLogRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Habit log not found with id: " + id));
        log.setCompleted(!log.isCompleted());
        return habitLogRepository.save(log);
    }

    public long countCompletedLogsByHabitId(Long habitId) {
        return habitLogRepository.countCompletedLogsByHabitId(habitId);
    }

    @Transactional
    public HabitLog logHabitForToday(Habit habit, boolean completed, String notes) {
        LocalDate today = LocalDate.now();
        Optional<HabitLog> existingLog = habitLogRepository.findByHabitAndDate(habit, today);
        
        if (existingLog.isPresent()) {
            HabitLog log = existingLog.get();
            log.setCompleted(completed);
            log.setNotes(notes);
            return habitLogRepository.save(log);
        } else {
            HabitLog newLog = new HabitLog();
            newLog.setHabit(habit);
            newLog.setDate(today);
            newLog.setCompleted(completed);
            newLog.setNotes(notes);
            return habitLogRepository.save(newLog);
        }
    }
}
