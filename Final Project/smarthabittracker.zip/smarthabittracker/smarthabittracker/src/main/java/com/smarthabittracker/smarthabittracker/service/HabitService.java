package com.smarthabittracker.smarthabittracker.service;

import com.smarthabittracker.smarthabittracker.model.Habit;
import com.smarthabittracker.smarthabittracker.model.User;
import com.smarthabittracker.smarthabittracker.repository.HabitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class HabitService {

    private final HabitRepository habitRepository;

    @Autowired
    public HabitService(HabitRepository habitRepository) {
        this.habitRepository = habitRepository;
    }

    public List<Habit> getAllHabits() {
        return habitRepository.findAll();
    }

    public List<Habit> getHabitsByUser(User user) {
        return habitRepository.findByUser(user);
    }

    public List<Habit> getActiveHabitsByUser(User user) {
        return habitRepository.findByUserAndStatus(user, Habit.Status.ACTIVE);
    }

    public List<Habit> getActiveHabitsByUserOrderByStartDate(User user) {
        return habitRepository.findByUserAndStatusOrderByStartDateDesc(user, Habit.Status.ACTIVE);
    }

    public List<Habit> getActiveHabitsByUserIdAndDate(Long userId, LocalDate date) {
        return habitRepository.findActiveHabitsByUserIdAndDate(userId, date);
    }

    public Optional<Habit> getHabitById(Long id) {
        return habitRepository.findById(id);
    }

    @Transactional
    public Habit createHabit(Habit habit) {
        if (habit.getStartDate() == null) {
            habit.setStartDate(LocalDate.now());
        }
        return habitRepository.save(habit);
    }

    @Transactional
    public Habit updateHabit(Habit habit) {
        return habitRepository.save(habit);
    }

    @Transactional
    public void deleteHabit(Long id) {
        habitRepository.deleteById(id);
    }

    @Transactional
    public Habit completeHabit(Long id) {
        Habit habit = habitRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Habit not found with id: " + id));
        habit.setStatus(Habit.Status.COMPLETED);
        return habitRepository.save(habit);
    }

    @Transactional
    public Habit abandonHabit(Long id) {
        Habit habit = habitRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Habit not found with id: " + id));
        habit.setStatus(Habit.Status.ABANDONED);
        return habitRepository.save(habit);
    }
}
