package com.smarthabittracker.smarthabittracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmarthabittrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmarthabittrackerApplication.class, args);
	}

}
