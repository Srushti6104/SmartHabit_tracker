package com.smarthabittracker.smarthabittracker.controller;

import com.smarthabittracker.smarthabittracker.model.Habit;
import com.smarthabittracker.smarthabittracker.model.HabitLog;
import com.smarthabittracker.smarthabittracker.model.User;
import com.smarthabittracker.smarthabittracker.service.HabitLogService;
import com.smarthabittracker.smarthabittracker.service.HabitService;
import com.smarthabittracker.smarthabittracker.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/habits")
public class HabitController {

    private final HabitService habitService;
    private final HabitLogService habitLogService;
    private final UserService userService;

    @Autowired
    public HabitController(HabitService habitService, HabitLogService habitLogService, UserService userService) {
        this.habitService = habitService;
        this.habitLogService = habitLogService;
        this.userService = userService;
    }

    @GetMapping
    public String listHabits(Model model) {
        User currentUser = getCurrentUser();
        List<Habit> habits = habitService.getHabitsByUser(currentUser);
        model.addAttribute("habits", habits);
        return "habits/list";
    }

    @GetMapping("/create")
    public String showCreateForm(Model model) {
        model.addAttribute("habit", new Habit());
        return "habits/create";
    }

    @PostMapping("/create")
    public String createHabit(@Valid @ModelAttribute("habit") Habit habit,
                             BindingResult result,
                             RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "habits/create";
        }

        User currentUser = getCurrentUser();
        habit.setUser(currentUser);
        habitService.createHabit(habit);
        
        redirectAttributes.addFlashAttribute("successMessage", "Habit created successfully!");
        return "redirect:/habits";
    }

    @GetMapping("/{id}")
    public String viewHabit(@PathVariable("id") Long id, Model model) {
        Optional<Habit> habitOpt = habitService.getHabitById(id);
        
        if (habitOpt.isPresent()) {
            Habit habit = habitOpt.get();
            
            // Security check - ensure the habit belongs to the current user
            if (!habit.getUser().getId().equals(getCurrentUser().getId())) {
                return "redirect:/habits?error";
            }
            
            List<HabitLog> logs = habitLogService.getLogsByHabitOrderByDateDesc(habit);
            long completedCount = habitLogService.countCompletedLogsByHabitId(id);
            
            model.addAttribute("habit", habit);
            model.addAttribute("logs", logs);
            model.addAttribute("completedCount", completedCount);
            model.addAttribute("newLog", new HabitLog());
            
            return "habits/view";
        }
        
        return "redirect:/habits?error";
    }

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Optional<Habit> habitOpt = habitService.getHabitById(id);
        
        if (habitOpt.isPresent()) {
            Habit habit = habitOpt.get();
            
            // Security check - ensure the habit belongs to the current user
            if (!habit.getUser().getId().equals(getCurrentUser().getId())) {
                return "redirect:/habits?error";
            }
            
            model.addAttribute("habit", habit);
            return "habits/edit";
        }
        
        return "redirect:/habits?error";
    }

    @PostMapping("/{id}/edit")
    public String updateHabit(@PathVariable("id") Long id,
                             @Valid @ModelAttribute("habit") Habit habit,
                             BindingResult result,
                             RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "habits/edit";
        }

        Optional<Habit> existingHabitOpt = habitService.getHabitById(id);
        
        if (existingHabitOpt.isPresent()) {
            Habit existingHabit = existingHabitOpt.get();
            
            // Security check - ensure the habit belongs to the current user
            if (!existingHabit.getUser().getId().equals(getCurrentUser().getId())) {
                return "redirect:/habits?error";
            }
            
            // Update fields but preserve the user
            existingHabit.setName(habit.getName());
            existingHabit.setDescription(habit.getDescription());
            existingHabit.setFrequency(habit.getFrequency());
            existingHabit.setTargetDays(habit.getTargetDays());
            existingHabit.setReminderTime(habit.getReminderTime());
            
            habitService.updateHabit(existingHabit);
            
            redirectAttributes.addFlashAttribute("successMessage", "Habit updated successfully!");
            return "redirect:/habits/" + id;
        }
        
        return "redirect:/habits?error";
    }

    @PostMapping("/{id}/delete")
    public String deleteHabit(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        Optional<Habit> habitOpt = habitService.getHabitById(id);
        
        if (habitOpt.isPresent()) {
            Habit habit = habitOpt.get();
            
            // Security check - ensure the habit belongs to the current user
            if (!habit.getUser().getId().equals(getCurrentUser().getId())) {
                return "redirect:/habits?error";
            }
            
            habitService.deleteHabit(id);
            redirectAttributes.addFlashAttribute("successMessage", "Habit deleted successfully!");
        }
        
        return "redirect:/habits";
    }

    @PostMapping("/{id}/complete")
    public String completeHabit(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        Optional<Habit> habitOpt = habitService.getHabitById(id);
        
        if (habitOpt.isPresent()) {
            Habit habit = habitOpt.get();
            
            // Security check - ensure the habit belongs to the current user
            if (!habit.getUser().getId().equals(getCurrentUser().getId())) {
                return "redirect:/habits?error";
            }
            
            habitService.completeHabit(id);
            redirectAttributes.addFlashAttribute("successMessage", "Habit marked as completed!");
        }
        
        return "redirect:/habits";
    }

    @PostMapping("/{id}/abandon")
    public String abandonHabit(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        Optional<Habit> habitOpt = habitService.getHabitById(id);
        
        if (habitOpt.isPresent()) {
            Habit habit = habitOpt.get();
            
            // Security check - ensure the habit belongs to the current user
            if (!habit.getUser().getId().equals(getCurrentUser().getId())) {
                return "redirect:/habits?error";
            }
            
            habitService.abandonHabit(id);
            redirectAttributes.addFlashAttribute("successMessage", "Habit marked as abandoned!");
        }
        
        return "redirect:/habits";
    }

    @PostMapping("/{id}/log")
    public String logHabit(@PathVariable("id") Long habitId,
                          @ModelAttribute("newLog") HabitLog habitLog,
                          RedirectAttributes redirectAttributes) {
        Optional<Habit> habitOpt = habitService.getHabitById(habitId);
        
        if (habitOpt.isPresent()) {
            Habit habit = habitOpt.get();
            
            // Security check - ensure the habit belongs to the current user
            if (!habit.getUser().getId().equals(getCurrentUser().getId())) {
                return "redirect:/habits?error";
            }
            
            // Set the habit and date if not already set
            habitLog.setHabit(habit);
            if (habitLog.getDate() == null) {
                habitLog.setDate(LocalDate.now());
            }
            
            // Check if a log already exists for this date
            Optional<HabitLog> existingLogOpt = habitLogService.getLogByHabitAndDate(habit, habitLog.getDate());
            
            if (existingLogOpt.isPresent()) {
                // Update existing log
                HabitLog existingLog = existingLogOpt.get();
                existingLog.setCompleted(habitLog.isCompleted());
                existingLog.setNotes(habitLog.getNotes());
                habitLogService.updateLog(existingLog);
            } else {
                // Create new log
                habitLogService.createLog(habitLog);
            }
            
            redirectAttributes.addFlashAttribute("successMessage", "Habit logged successfully!");
        }
        
        return "redirect:/habits/" + habitId;
    }

    @PostMapping("/logs/{logId}/toggle")
    public String toggleLogCompletion(@PathVariable("logId") Long logId,
                                     @RequestParam("habitId") Long habitId,
                                     RedirectAttributes redirectAttributes) {
        Optional<HabitLog> logOpt = habitLogService.getLogById(logId);
        
        if (logOpt.isPresent()) {
            HabitLog log = logOpt.get();
            
            // Security check - ensure the log belongs to the current user's habit
            if (!log.getHabit().getUser().getId().equals(getCurrentUser().getId())) {
                return "redirect:/habits?error";
            }
            
            habitLogService.toggleCompletion(logId);
            redirectAttributes.addFlashAttribute("successMessage", "Log status updated!");
        }
        
        return "redirect:/habits/" + habitId;
    }

    private User getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return userService.getUserByUsername(auth.getName())
                .orElseThrow(() -> new RuntimeException("Current user not found"));
    }
}
